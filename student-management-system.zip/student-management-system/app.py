from flask import Flask, render_template, request, redirect

app = Flask(__name__)

FILE_NAME = 'students.txt'

def read_students():
    students = []
    try:
        with open(FILE_NAME, 'r') as file:
            for line in file:
                data = line.strip().split(',')
                if len(data) == 3:
                    students.append({
                        'name': data[0],
                        'roll': data[1],
                        'course': data[2]
                    })
    except FileNotFoundError:
        pass

    return students

@app.route('/')
def home():
    students = read_students()
    return render_template('index.html', students=students)

@app.route('/add', methods=['POST'])
def add_student():
    name = request.form['name']
    roll = request.form['roll']
    course = request.form['course']

    with open(FILE_NAME, 'a') as file:
        file.write(f"{name},{roll},{course}\n")

    return redirect('/')

@app.route('/delete/<roll>')
def delete_student(roll):
    students = read_students()

    with open(FILE_NAME, 'w') as file:
        for student in students:
            if student['roll'] != roll:
                file.write(f"{student['name']},{student['roll']},{student['course']}\n")

    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
